#!/bin/bash

[[ -d ../releng ]] && rm -r ../releng

cp -r /usr/share/archiso/configs/releng/ ../

[[ -d ../releng/airootfs/etc/systemd/network ]] && rm -r ../releng/airootfs/etc/systemd/network

[[ -f ../releng/airootfs/etc/resolv.conf ]] && rm ../releng/airootfs/etc/resolv.conf

cp build.sh ../releng/

cp packages.x86_64 ../releng/

cp customize_airootfs.sh ../releng/airootfs/root/

cp splash.png ../releng/syslinux/

cp archiso_head.cfg ../releng/syslinux/

cp ezarch* ../releng/airootfs/root/

cp readme.txt ../releng/airootfs/root/

cd ../releng

./build.sh
