
EZArch CLI Builder
https://sourceforge.net/projects/ezarch/

The EZArcher CLI build project is a simple set of files and a steps.sh script to automate the building of an Arch Linux ISO that contains the stock Arch Linux installation media with the ezarch install scripts included in the ISO.

The steps.sh file copies the necessary files into the archiso build folder, in this case, "releng" and runs the build.sh script to produce the Arch Linux installation ISO image. The standard Arch selected packages are used and the customize_airottfs.sh is used unmodified. 

The resulting ISO image file is created in the releng/out folder and ready for use. The ezarch.bios, ezarch.uefi, and ezarcher scripts will be located in the /root/ folder where the live archiso places the user when fully booted. In order to run the release versions of the ezarch install scripts, simply type: ./ezarch.bios or ./ezarch.uefi depending on the type of installation required. The ezarcher script can be used instead to download the freshest copies of the install scripts or to use the development versions located on my Sourceforge project page.

All of my scripts and documents are free for public use and adaptation. Please use and enjoy. Thank you. :-)


